package org.kdea.sgp.notice;

public class BoardLoginVO {
private String ename;
private String empno;
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getEmpno() {
	return empno;
}
public void setEmpno(String empno) {
	this.empno = empno;
}


}
