package org.kdea.sgp.mainpage;

public interface MainpageDAO {

	public int logingo(LoginVO lvo);

	public int getTemp(LoginVO lvo);

	

}
